package com.dhaana.app

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class MainActivity : AppCompatActivity() {

    // Replace this with your verified UPI ID before publishing.
    private val merchantUpiId = "mithunpachanady@ybl"
    private val merchantName = "DHAANA"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(24))
        }

        content.addView(TextView(this).apply {
            text = "DHAANA"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(27, 94, 32))
            setTypeface(null, android.graphics.Typeface.BOLD)
        }, wrap())

        content.addView(TextView(this).apply {
            text = "Support a family with food and essentials"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
        }, wrap())

        content.addView(ImageView(this).apply {
            setImageResource(R.drawable.donation_photo)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }, LinearLayout.LayoutParams(-1, dp(220)).apply {
            setMargins(0, dp(12), 0, dp(8))
        })

        content.addView(ImageView(this).apply {
            setImageResource(R.drawable.charity_words)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }, LinearLayout.LayoutParams(-1, dp(150)).apply {
            setMargins(0, 0, 0, dp(14))
        })

        content.addView(TextView(this).apply {
            text = "Choose an amount"
            textSize = 20f
            setTextColor(Color.rgb(27, 94, 32))
            setTypeface(null, android.graphics.Typeface.BOLD)
        }, wrap())

        val amountInput = EditText(this).apply {
            hint = "Enter custom amount"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            textSize = 18f
            setSingleLine(true)
        }

        val grid = GridLayout(this).apply { columnCount = 3 }
        listOf(5, 10, 20, 50, 100, 500, 1000).forEach { amount ->
            grid.addView(Button(this).apply {
                text = "₹$amount"
                textSize = 16f
                setOnClickListener { amountInput.setText(amount.toString()) }
            }, GridLayout.LayoutParams().apply {
                width = 0
                height = dp(52)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(3), dp(3), dp(3), dp(3))
            })
        }
        content.addView(grid, wrap())
        content.addView(amountInput, LinearLayout.LayoutParams(-1, dp(60)).apply {
            setMargins(0, dp(6), 0, dp(6))
        })

        content.addView(Button(this).apply {
            text = "PAY NOW"
            textSize = 18f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(27, 94, 32))
            setOnClickListener { startUpiPayment(amountInput.text.toString()) }
        }, LinearLayout.LayoutParams(-1, dp(58)).apply {
            setMargins(0, dp(8), 0, dp(10))
        })

        content.addView(TextView(this).apply {
            text = "Thanks for your support\nGod bless you"
            textSize = 17f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
        }, wrap())

        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun startUpiPayment(raw: String) {
        val amount = raw.toDoubleOrNull()
        if (amount == null || amount <= 0) {
            Toast.makeText(this, "Please enter a valid amount.", Toast.LENGTH_SHORT).show()
            return
        }
        if (merchantUpiId.startsWith("YOUR_")) {
            Toast.makeText(this, "Set your verified UPI ID in MainActivity.kt first.", Toast.LENGTH_LONG).show()
            return
        }

        val uri = Uri.parse(String.format(
            Locale.US,
            "upi://pay?pa=%s&pn=%s&am=%.2f&cu=INR&tn=%s",
            Uri.encode(merchantUpiId),
            Uri.encode(merchantName),
            amount,
            Uri.encode("DHAANA support")
        ))

        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (e: Exception) {
            Toast.makeText(this, "No UPI app found on this device.", Toast.LENGTH_LONG).show()
        }
    }

    private fun wrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
